TokiNote Focus component 1.0.0

This package enables the optional Focus entry in the TokiNote bottom bar.

The package is installed locally by TokiNote and can be removed from
Settings > Components at any time.
